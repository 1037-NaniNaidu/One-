/* Areev Sales Manager
   Local-first storage with optional encrypted Google Drive app-data backup.
   Firebase has been completely removed.
*/
const $ = (id) => document.getElementById(id);
const todayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
};
const money = (n) => "₹" + Number(n || 0).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2});
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const cleanPhone = (s) => String(s).replace(/\D/g,"");
const accountKeyFor = (business, phone) => {
  const source = `${business.trim().toLowerCase()}|${cleanPhone(phone)}`;
  let h = 2166136261;
  for (let i=0;i<source.length;i++){h ^= source.charCodeAt(i);h = Math.imul(h,16777619);}
  return (h>>>0).toString(16).padStart(8,"0");
};

let account = null, accountKey = "", data = emptyData(), cart = [], saveTimer = null, lastDay = todayKey();
let driveAccessToken = null, driveTokenClient = null, pendingDriveAction = null;
const LOCAL_PREFIX = "areev_sales_manager_local_v2_";
const CLIENT_ID_KEY = "areev_sales_manager_google_client_id";
function emptyData(){return {products:[],customers:[],sales:[],notes:{},trash:[],ledger:[],updatedAt:new Date().toISOString()};}
function localStorageKey(){return LOCAL_PREFIX + accountKey;}
function showAuth(message="", isSuccess=false){
  $("authScreen").classList.remove("hidden");$("app").classList.add("hidden");
  $("authMessage").textContent=message;$("authMessage").className="message"+(isSuccess?" success":"");
}
function showApp(){
  $("authScreen").classList.add("hidden");$("app").classList.remove("hidden");
  $("headerBusiness").textContent=account.businessName;
  $("profileDetails").textContent=`Business: ${account.businessName} · Phone: ${account.phone}`;
  $("googleClientId").value=localStorage.getItem(CLIENT_ID_KEY)||"";
  showPage("dashboard");renderAll();
}
function loadLocalData(){
  const raw=localStorage.getItem(localStorageKey());
  if(raw){
    try{
      const saved=JSON.parse(raw);
      data={...emptyData(),...(saved.data||saved)};
      if(!data.notes)data.notes={};
      if(!Array.isArray(data.trash))data.trash=[];
      return true;
    }catch(e){console.error("Saved local data could not be read",e);}
  }
  data=emptyData();
  saveLocal(true);
  return false;
}
function saveLocal(silent=false){
  if(!accountKey)return;
  data.updatedAt=new Date().toISOString();
  try{
    localStorage.setItem(localStorageKey(),JSON.stringify({account,data}));
    if(!silent && $("noteSaveStatus")) $("noteSaveStatus").textContent="Saved on this device";
  }catch(error){
    console.error(error);
    if($("noteSaveStatus")) $("noteSaveStatus").textContent="Save failed — device storage may be full";
  }
}
function queueSave(){
  clearTimeout(saveTimer);
  saveTimer=setTimeout(()=>saveLocal(),400);
}
function logout(){
  account=null;accountKey="";data=emptyData();cart=[];driveAccessToken=null;showAuth();
}

/* Google Drive backup uses the private appDataFolder and encrypts the backup
   with the business password before upload. Only this app can access this folder. */
function setDriveStatus(message, success=false){
  const el=$("driveStatus");
  if(el){el.textContent=message;el.className="message"+(success?" success":"");}
}
function getGoogleClientId(){return (localStorage.getItem(CLIENT_ID_KEY)||"").trim();}
function initDriveTokenClient(){
  const clientId=getGoogleClientId();
  if(!clientId){setDriveStatus("Enter and save your Google OAuth Client ID first.");return false;}
  if(!window.google?.accounts?.oauth2){setDriveStatus("Google sign-in library is still loading. Wait a moment and try again.");return false;}
  driveTokenClient=google.accounts.oauth2.initTokenClient({
    client_id:clientId,
    scope:"https://www.googleapis.com/auth/drive.appdata",
    callback:(response)=>{
      if(response.error){setDriveStatus("Google Drive connection failed: "+response.error);return;}
      driveAccessToken=response.access_token;
      setDriveStatus("Google Drive connected for this session.",true);
      if(pendingDriveAction){const action=pendingDriveAction;pendingDriveAction=null;action();}
    }
  });
  return true;
}
function connectDrive(action){
  pendingDriveAction=action||null;
  if(!initDriveTokenClient())return;
  driveTokenClient.requestAccessToken({prompt:driveAccessToken?"":"consent"});
}
async function deriveEncryptionKey(password,salt){
  const enc=new TextEncoder();
  const material=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:250000,hash:"SHA-256"},material,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
}
function bytesToBase64(bytes){
  let binary="";bytes.forEach(b=>binary+=String.fromCharCode(b));return btoa(binary);
}
function base64ToBytes(value){
  const binary=atob(value);return Uint8Array.from(binary,c=>c.charCodeAt(0));
}
async function encryptBackup(){
  const salt=crypto.getRandomValues(new Uint8Array(16));
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await deriveEncryptionKey($("password").value,salt);
  const plain=new TextEncoder().encode(JSON.stringify({account,data}));
  const cipher=await crypto.subtle.encrypt({name:"AES-GCM",iv},key,plain);
  return {format:"areev-encrypted-backup-v1",accountKey,salt:bytesToBase64(salt),iv:bytesToBase64(iv),ciphertext:bytesToBase64(new Uint8Array(cipher))};
}
async function decryptBackup(payload){
  if(payload.format!=="areev-encrypted-backup-v1"||payload.accountKey!==accountKey)throw new Error("This backup does not match the business name and phone number entered.");
  const key=await deriveEncryptionKey($("password").value,base64ToBytes(payload.salt));
  const plain=await crypto.subtle.decrypt({name:"AES-GCM",iv:base64ToBytes(payload.iv)},key,base64ToBytes(payload.ciphertext));
  const parsed=JSON.parse(new TextDecoder().decode(plain));
  if(!parsed.data||!parsed.account)throw new Error("Backup file is incomplete.");
  return parsed;
}
async function driveRequest(url,options={}){
  if(!driveAccessToken)throw new Error("Connect Google Drive first.");
  const response=await fetch(url,{...options,headers:{...(options.headers||{}),Authorization:"Bearer "+driveAccessToken}});
  if(!response.ok){const detail=await response.text();throw new Error(`Google Drive error (${response.status}): ${detail.slice(0,180)}`);}
  return response;
}
async function backupToDrive(){
  try{
    setDriveStatus("Preparing encrypted backup...");
    const payload=await encryptBackup();
    const fileName=`Areev-Sales-Manager-${accountKey}.backup`;
    const query=encodeURIComponent(`name='${fileName}' and 'appDataFolder' in parents and trashed=false`);
    const search=await driveRequest(`https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${query}&fields=files(id,name)`);
    const found=await search.json();
    const metadata={name:fileName,mimeType:"application/json",parents:["appDataFolder"]};
    const boundary="areev_boundary_"+uid().replace(/-/g,"");
    const body="--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+JSON.stringify(metadata)+"\r\n--"+boundary+"\r\nContent-Type: application/json\r\n\r\n"+JSON.stringify(payload)+"\r\n--"+boundary+"--";
    let url,method;
    if(found.files?.length){url=`https://www.googleapis.com/upload/drive/v3/files/${found.files[0].id}?uploadType=multipart`;method="PATCH";}
    else{url="https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";method="POST";}
    await driveRequest(url,{method,headers:{"Content-Type":"multipart/related; boundary="+boundary},body});
    setDriveStatus("Encrypted backup saved to Google Drive.",true);
  }catch(error){console.error(error);setDriveStatus(error.message||"Backup failed.");}
}
async function restoreFromDrive(){
  try{
    setDriveStatus("Searching Google Drive for your backup...");
    const fileName=`Areev-Sales-Manager-${accountKey}.backup`;
    const query=encodeURIComponent(`name='${fileName}' and 'appDataFolder' in parents and trashed=false`);
    const search=await driveRequest(`https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${query}&fields=files(id,name,modifiedTime)&orderBy=modifiedTime desc`);
    const found=await search.json();
    if(!found.files?.length){setDriveStatus("No backup found for this business name and phone number.");return;}
    const file=found.files[0];
    const response=await driveRequest(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`);
    const payload=await response.json();
    const restored=await decryptBackup(payload);
    if(!confirm("Restore this Google Drive backup? It will replace the current data on this device."))return;
    account=restored.account;data={...emptyData(),...restored.data};
    saveLocal(true);showApp();setDriveStatus("Backup restored successfully.",true);
  }catch(error){
    console.error(error);
    setDriveStatus(error.name==="OperationError"?"Could not decrypt backup. Check that you entered the same password used when creating it.":(error.message||"Restore failed."));
  }
}

function showPage(name){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  const page=$(name+"Page");if(page)page.classList.add("active");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  if(name==="reports")renderReports();if(name==="monthly")renderLedger();if(name==="recycle")renderTrash();
}
function trashItem(type,item,label){
  data.trash.push({id:uid(),type,item,label:label||type,deletedAt:new Date().toISOString(),expiresAt:Date.now()+10*86400000});
}
function purgeExpiredTrash(){
  const now=Date.now();data.trash=data.trash.filter(t=>new Date(t.expiresAt).getTime()>now);
}
function archiveExpiredNotes(){
  const today=todayKey();
  Object.keys(data.notes).forEach(day=>{
    if(day<today && data.notes[day] && data.notes[day].text){
      const already=data.trash.some(t=>t.type==="note" && t.item.date===day);
      if(!already)trashItem("note",{date:day,text:data.notes[day].text},`Daily note · ${day}`);
      delete data.notes[day];
    }
  });
  lastDay=today;purgeExpiredTrash();queueSave();
}
function updateClock(){
  const now=new Date();$("liveClock").textContent=now.toLocaleTimeString("en-IN",{hour12:true});
  if(todayKey()!==lastDay){archiveExpiredNotes();$("noteDate").value=todayKey();$("dayNote").value="";$("archivedNoteHint").textContent="Yesterday's note was moved to the recycle bin.";}
}
function renderDashboard(){
  const day=todayKey(),sales=data.sales.filter(s=>s.date===day);
  const total=sales.reduce((a,s)=>a+Number(s.total||0),0);
  const items=sales.reduce((a,s)=>a+s.items.reduce((x,i)=>x+Number(i.qty||0),0),0);
  $("todaySales").textContent=money(total);$("todayItems").textContent=items;$("todayOrders").textContent=sales.length;
  const byProduct={};
  sales.forEach(s=>s.items.forEach(i=>{byProduct[i.name]=(byProduct[i.name]||0)+Number(i.qty||0);}));
  const rows=Object.entries(byProduct).sort((a,b)=>b[1]-a[1]);
  $("todayProductList").innerHTML=rows.length?rows.map(([n,q])=>`<div class="compact-row"><span>${escapeHtml(n)}</span><strong>${q} sold</strong></div>`).join(""):'<p class="empty">No sales recorded today.</p>';
  const recent=[...sales].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,5);
  $("recentSales").innerHTML=recent.length?recent.map(s=>`<div class="data-row"><span>${escapeHtml(s.customerName||"Walk-in")} · ${s.items.reduce((x,i)=>x+i.qty,0)} items</span><strong>${money(s.total)}</strong></div>`).join(""):'<p class="empty">No sales recorded today.</p>';
}
function renderNotes(){
  const day=$("noteDate").value||todayKey();const note=data.notes[day];
  $("dayNote").value=note?.text||"";
  $("noteSaveStatus").textContent=note?"Saved note loaded":"No note for this date";
  $("archivedNoteHint").textContent=day<todayKey()?"Past-date notes are read-only after midnight. If expired, check the recycle bin.":"";
  $("dayNote").disabled=day<todayKey();
  $("saveNoteButton").disabled=day<todayKey();
}
function renderProducts(){
  const q=$("productSearch").value.toLowerCase();
  const items=data.products.filter(p=>p.name.toLowerCase().includes(q));
  $("productList").innerHTML=items.length?`<div class="table-wrap"><table><thead><tr><th>Product</th><th>Price</th><th>Stock left</th><th>Actions</th></tr></thead><tbody>${items.map(p=>`<tr><td>${escapeHtml(p.name)}</td><td>${money(p.price)}</td><td class="${p.stock<5?'stock-low':''}">${p.stock}</td><td><div class="row-actions"><button class="mini-btn" data-edit-product="${p.id}">Edit</button><button class="mini-btn danger" data-delete-product="${p.id}">Delete</button></div></td></tr>`).join("")}</tbody></table></div>`:'<p class="empty">No products added yet.</p>';
  $("saleProduct").innerHTML='<option value="">Choose a product</option>'+data.products.map(p=>`<option value="${p.id}">${escapeHtml(p.name)} · ${money(p.price)} · Stock ${p.stock}</option>`).join("");
}
function renderCustomers(){
  const q=$("customerSearch").value.toLowerCase();
  const items=data.customers.filter(c=>(c.name+" "+c.phone).toLowerCase().includes(q));
  $("customerList").innerHTML=items.length?items.map(c=>`<div class="data-row"><div><strong>${escapeHtml(c.name)}</strong><div class="small muted">${escapeHtml(c.phone||"No phone")} ${c.details?"· "+escapeHtml(c.details):""}</div></div><div class="row-actions"><button class="mini-btn" data-edit-customer="${c.id}">Edit</button><button class="mini-btn danger" data-delete-customer="${c.id}">Delete</button></div></div>`).join(""):'<p class="empty">No customers added yet.</p>';
  const opts='<option value="">Walk-in customer</option>'+data.customers.map(c=>`<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("");
  $("saleCustomer").innerHTML=opts;
  $("ledgerCustomer").innerHTML='<option value="">Choose a customer</option>'+data.customers.map(c=>`<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("");
}
function renderCart(){
  $("cartList").innerHTML=cart.length?cart.map((i,index)=>`<div class="data-row"><span>${escapeHtml(i.name)} × ${i.qty}</span><span>${money(i.price*i.qty)} <button class="mini-btn danger" data-remove-cart="${index}">Remove</button></span></div>`).join(""):'<p class="empty">No items added.</p>';
  $("cartTotal").textContent=money(cart.reduce((a,i)=>a+i.price*i.qty,0));
}
function renderLedger(){
  const id=$("ledgerCustomer").value;
  if(!id){$("ledgerSummary").innerHTML="Select a customer to see their account."; $("ledgerHistory").innerHTML="";return;}
  const customer=data.customers.find(c=>c.id===id);if(!customer)return;
  const month=todayKey().slice(0,7);
  const sales=data.sales.filter(s=>s.customerId===id&&s.date.startsWith(month));
  const paid=data.ledger.filter(x=>x.customerId===id&&x.date.startsWith(month)).reduce((a,x)=>a+x.amount,0);
  const bought=sales.reduce((a,s)=>a+s.total,0);
  $("ledgerSummary").innerHTML=`<strong>${escapeHtml(customer.name)}</strong><p>Month: ${month}</p><p>Purchases: ${money(bought)} · Payments: ${money(paid)} · <strong>Balance: ${money(bought-paid)}</strong></p>`;
  const history=[...sales.map(s=>({date:s.date,label:"Purchase",amount:s.total})),...data.ledger.filter(x=>x.customerId===id&&x.date.startsWith(month)).map(x=>({date:x.date,label:"Payment received",amount:-x.amount}))].sort((a,b)=>a.date.localeCompare(b.date));
  $("ledgerHistory").innerHTML=history.length?history.map(x=>`<div class="data-row"><span>${x.date} · ${x.label}</span><strong>${money(Math.abs(x.amount))}</strong></div>`).join(""):'<p class="empty">No transactions this month.</p>';
}
function renderTrash(){
  purgeExpiredTrash();
  $("recycleList").innerHTML=data.trash.length?data.trash.map(t=>`<div class="data-row"><div><strong>${escapeHtml(t.label)}</strong><div class="small muted">Expires ${new Date(t.expiresAt).toLocaleDateString()}</div></div><div class="row-actions"><button class="mini-btn" data-restore="${t.id}">Restore</button><button class="mini-btn danger" data-permanent="${t.id}">Delete forever</button></div></div>`).join(""):'<p class="empty">Recycle bin is empty.</p>';
}
function renderReports(){
  const from=$("reportFrom").value||todayKey().slice(0,7)+"-01",to=$("reportTo").value||todayKey();
  const sales=data.sales.filter(s=>s.date>=from&&s.date<=to).sort((a,b)=>a.date.localeCompare(b.date));
  $("reportSummary").innerHTML=`<div class="report-summary"><span>Orders: ${sales.length}</span><span>Total sales: ${money(sales.reduce((a,s)=>a+s.total,0))}</span><span>Items: ${sales.reduce((a,s)=>a+s.items.reduce((x,i)=>x+i.qty,0),0)}</span></div>`;
  $("reportTable").innerHTML=sales.length?`<div class="table-wrap"><table><thead><tr><th>Date</th><th>Customer type</th><th>Items</th><th>Total</th></tr></thead><tbody>${sales.map(s=>`<tr><td>${s.date}</td><td>${escapeHtml(s.customerName||"Walk-in")}</td><td>${s.items.map(i=>`${escapeHtml(i.name)} × ${i.qty}`).join(", ")}</td><td>${money(s.total)}</td></tr>`).join("")}</tbody></table></div>`:'<p class="empty">No sales in this date range.</p>';
}
function renderAll(){renderDashboard();renderNotes();renderProducts();renderCustomers();renderCart();renderLedger();renderTrash();renderReports();}
function clearProductForm(){ $("productForm").reset();$("productId").value=""; }
function clearCustomerForm(){ $("customerForm").reset();$("customerId").value=""; }

$("authForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const business=$("businessName").value.trim(),phone=$("phoneNumber").value.trim(),password=$("password").value;
  if(business.length<2||cleanPhone(phone).length<7){showAuth("Enter a valid business name and phone number.");return;}
  if(password.length<6){showAuth("Password must contain at least 6 characters.");return;}
  $("loginButton").disabled=true;$("loginButton").textContent="Opening...";
  try{
    account={businessName:business,phone};
    accountKey=accountKeyFor(business,phone);
    const isNew=!loadLocalData();
    showApp();
    if(isNew) $("noteSaveStatus").textContent="New local workspace created. Restore a Drive backup from Settings if you have one.";
  }catch(err){console.error(err);showAuth(err.message||"Unable to open this business workspace.");}
  finally{$("loginButton").disabled=false;$("loginButton").textContent="Continue";}
});
$("logoutButton").addEventListener("click",logout);$("logoutButton2").addEventListener("click",logout);

document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));
$("noteDate").value=todayKey();
$("noteDate").addEventListener("change",renderNotes);
$("dayNote").addEventListener("input",()=>{
  const day=$("noteDate").value||todayKey();
  data.notes[day]={text:$("dayNote").value,updatedAt:new Date().toISOString()};
  $("noteSaveStatus").textContent="Saving...";
  clearTimeout(saveTimer);saveTimer=setTimeout(()=>saveLocal(),700);
});
$("saveNoteButton").addEventListener("click",async()=>{const day=$("noteDate").value||todayKey();data.notes[day]={text:$("dayNote").value,updatedAt:new Date().toISOString()};await saveLocal();});
$("productForm").addEventListener("submit",e=>{
  e.preventDefault();const id=$("productId").value,name=$("productName").value.trim(),price=Number($("productPrice").value),stock=Number($("productStock").value);
  if(!name||price<0||stock<0)return;
  if(id){const p=data.products.find(x=>x.id===id);if(p)Object.assign(p,{name,price,stock});}
  else data.products.push({id:uid(),name,price,stock});
  clearProductForm();renderProducts();queueSave();
});
$("cancelProductEdit").addEventListener("click",clearProductForm);
$("productSearch").addEventListener("input",renderProducts);
$("productList").addEventListener("click",e=>{
  const edit=e.target.dataset.editProduct,del=e.target.dataset.deleteProduct;
  if(edit){const p=data.products.find(x=>x.id===edit);if(!p)return;$("productId").value=p.id;$("productName").value=p.name;$("productPrice").value=p.price;$("productStock").value=p.stock;window.scrollTo({top:0,behavior:"smooth"});}
  if(del){const p=data.products.find(x=>x.id===del);if(!p)return;if(confirm(`Move ${p.name} to recycle bin?`)){trashItem("product",p,p.name);data.products=data.products.filter(x=>x.id!==del);renderAll();queueSave();}}
});
$("customerForm").addEventListener("submit",e=>{
  e.preventDefault();const id=$("customerId").value,customer={name:$("customerName").value.trim(),phone:$("customerPhone").value.trim(),details:$("customerDetails").value.trim()};
  if(!customer.name)return;
  if(id){const c=data.customers.find(x=>x.id===id);if(c)Object.assign(c,customer);}
  else data.customers.push({id:uid(),...customer});
  clearCustomerForm();renderCustomers();queueSave();
});
$("cancelCustomerEdit").addEventListener("click",clearCustomerForm);$("customerSearch").addEventListener("input",renderCustomers);
$("customerList").addEventListener("click",e=>{
  const edit=e.target.dataset.editCustomer,del=e.target.dataset.deleteCustomer;
  if(edit){const c=data.customers.find(x=>x.id===edit);if(!c)return;$("customerId").value=c.id;$("customerName").value=c.name;$("customerPhone").value=c.phone;$("customerDetails").value=c.details;}
  if(del){const c=data.customers.find(x=>x.id===del);if(!c)return;if(confirm(`Move ${c.name} to recycle bin?`)){trashItem("customer",c,c.name);data.customers=data.customers.filter(x=>x.id!==del);renderAll();queueSave();}}
});
$("saleProduct").addEventListener("change",()=>{
  const p=data.products.find(x=>x.id===$("saleProduct").value);
  $("saleUnitPrice").value=p?Number(p.price).toFixed(2):"";
});
$("addToCartButton").addEventListener("click",()=>{
  const p=data.products.find(x=>x.id===$("saleProduct").value),qty=Number($("saleQuantity").value),price=Number($("saleUnitPrice").value);
  if(!p){$("saleMessage").textContent="Choose a product.";return;}
  if(!Number.isInteger(qty)||qty<1||qty>p.stock){$("saleMessage").textContent=`Enter a quantity between 1 and ${p.stock}.`;return;}
  if(!Number.isFinite(price)||price<0){$("saleMessage").textContent="Enter a valid unit price.";return;}
  cart.push({productId:p.id,name:p.name,qty,price});$("saleMessage").textContent="";renderCart();
});
$("cartList").addEventListener("click",e=>{const i=e.target.dataset.removeCart;if(i!==undefined){cart.splice(Number(i),1);renderCart();}});
$("completeSaleButton").addEventListener("click",async()=>{
  if(!cart.length){$("saleMessage").textContent="Add at least one product.";return;}
  for(const item of cart){const p=data.products.find(x=>x.id===item.productId);if(!p||p.stock<item.qty){$("saleMessage").textContent=`Not enough stock for ${item.name}.`;return;}}
  const customer=data.customers.find(c=>c.id===$("saleCustomer").value);
  const sale={id:uid(),date:todayKey(),createdAt:new Date().toISOString(),customerId:customer?.id||"",customerName:customer?.name||"Walk-in",items:cart.map(x=>({...x})),total:cart.reduce((a,x)=>a+x.qty*x.price,0)};
  sale.items.forEach(item=>{const p=data.products.find(x=>x.id===item.productId);p.stock-=item.qty;});
  data.sales.push(sale);cart=[];renderAll();$("saleMessage").textContent="Sale saved successfully."; $("saleMessage").className="message success";await saveLocal();
});
$("ledgerCustomer").addEventListener("change",renderLedger);
$("paymentForm").addEventListener("submit",e=>{
  e.preventDefault();const id=$("ledgerCustomer").value,amount=Number($("paymentAmount").value);
  if(!id||amount<=0)return;
  data.ledger.push({id:uid(),customerId:id,amount,date:todayKey(),note:$("paymentNote").value.trim()});
  $("paymentForm").reset();renderLedger();queueSave();
});
$("reportFrom").value=todayKey().slice(0,7)+"-01";$("reportTo").value=todayKey();
$("reportFrom").addEventListener("change",renderReports);$("reportTo").addEventListener("change",renderReports);
$("printReportButton").addEventListener("click",()=>window.print());
$("recycleList").addEventListener("click",e=>{
  const restore=e.target.dataset.restore,permanent=e.target.dataset.permanent;
  if(restore){const t=data.trash.find(x=>x.id===restore);if(!t)return;
    if(t.type==="product")data.products.push(t.item);
    else if(t.type==="customer")data.customers.push(t.item);
    else if(t.type==="note")data.notes[t.item.date]={text:t.item.text,updatedAt:new Date().toISOString()};
    data.trash=data.trash.filter(x=>x.id!==restore);renderAll();queueSave();}
  if(permanent){if(confirm("Permanently delete this item?")){data.trash=data.trash.filter(x=>x.id!==permanent);renderTrash();queueSave();}}
});
$("emptyBinButton").addEventListener("click",()=>{if(confirm("Permanently delete everything in the recycle bin?")){data.trash=[];renderTrash();queueSave();}});
$("exportButton").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify({account,data},null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="areev-sales-manager-backup.json";a.click();URL.revokeObjectURL(url);
});


$("saveGoogleClientId").addEventListener("click",()=>{
  const value=$("googleClientId").value.trim();
  if(!value){setDriveStatus("Paste your Google OAuth Client ID.");return;}
  localStorage.setItem(CLIENT_ID_KEY,value);
  setDriveStatus("Google Client ID saved on this device.",true);
});
$("driveConnectButton").addEventListener("click",()=>connectDrive());
$("driveBackupButton").addEventListener("click",()=>connectDrive(backupToDrive));
$("driveRestoreButton").addEventListener("click",()=>connectDrive(restoreFromDrive));
$("importBackupInput").addEventListener("change",async e=>{
  const file=e.target.files?.[0];if(!file)return;
  try{
    const parsed=JSON.parse(await file.text());
    if(parsed.format==="areev-encrypted-backup-v1"){
      const restored=await decryptBackup(parsed);
      account=restored.account;data={...emptyData(),...restored.data};
    }else if(parsed.data&&parsed.account){
      account=parsed.account;data={...emptyData(),...parsed.data};
    }else throw new Error("This is not a valid Areev backup file.");
    saveLocal(true);showApp();alert("Backup imported successfully.");
  }catch(err){alert(err.message||"Could not import this backup.");}
  e.target.value="";
});

setInterval(updateClock,1000);
updateClock();
